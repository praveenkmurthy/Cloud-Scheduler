#!/bin/sh

# create required directories
mkdir -p /etc/overlord
mkdir -p /etc/overlord-agent
mkdir -p /usr/bin/overlord
mkdir -p /usr/bin/overlord-agent
mkdir -p /var/log/overlord
mkdir -p /var/log/overlord-agent

# copy overlord-agent jars
install -v -m 755 -D ./jar/mesos-elasticity-plugin.jar /usr/bin/overlord-agent
install -v -m 755 -D ./jar/mesos-collector-plugin.jar /usr/bin/overlord-agent
install -v -m 755 -D ./jar/openstack-cluster-scaler-plugin.jar /usr/bin/overlord-agent
install -v -m 755 -D ./jar/sqlitedb-executor-plugin.jar /usr/bin/overlord-agent
install -v -m 755 -D ./jar/agent.jar /usr/bin/overlord-agent
install -v -m 755 -D ./jar/aging-policyinfo-plugin.jar /usr/bin/overlord-agent

# copy overlord jars
install -v -m 755 -D ./jar/overlord.jar /usr/bin/overlord
install -v -m 755 -D ./jar/aging-policy-plugin.jar /usr/bin/overlord
install -v -m 755 -D ./jar/openstack-cloudinfo-collector-plugin.jar /usr/bin/overlord

# copy overlord config
install -v -m 644 -D ./conf/overlord/config.json /etc/overlord

# copy overlord-agent config
install -v -m 644 -D ./conf/overlord-agent/config.json /etc/overlord-agent

# copy DB schema
install -v -m 644 -D ./db/db.schema /etc/overlord-agent

# copy startup script
install -v -m 755 -D ./bin/overlord /etc/init.d/
install -v -m 755 -D ./bin/overlord-agent /etc/init.d/

# add the service
update-rc.d overlord defaults
update-rc.d overlord enable

update-rc.d overlord-agent defaults
update-rc.d overlord-agent enable
